sudo wget -O "/root/speedtest" "https://raw.githubusercontent.com/BlueSkyXN/ChangeSource/master/speedtest" --no-check-certificate -T 30 -t 5 -d
sudo chmod +x "/root/speedtest"
sudo chmod 777 "/root/speedtest"
sudo wget -O "/root/lovespeed.sh" "https://raw.githubusercontent.com/BlueSkyXN/lovespeed/main/lovespeed.sh" --no-check-certificate -T 30 -t 5 -d
sudo chmod +x "/root/lovespeed.sh"
sudo chmod 777 "/root/lovespeed.sh"
