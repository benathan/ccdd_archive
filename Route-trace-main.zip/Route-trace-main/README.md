# Route-trace
Linux 回程路由追踪检测智能一键脚本

# USE

wget -O rt.sh https://raw.githubusercontent.com/BlueSkyXN/Route-trace/main/rt.sh && chmod +x rt.sh && clear && ./rt.sh

# 原作
https://www.moerats.com/archives/497/
